Supplementary materials for the paper "Screen-Space Blue-Noise Diffusion of Monte Carlo Sampling Error via Hierarchical Ordering of Pixels".

Please contact the first author at abdalla_gafar@hotmail.com for any questions.

================================================================================

Code:

0- We provide a working implementation of our sampler for PBRT-3
1- The files z.h, zhash.h, zcommon.h, z.cpp, zhash.cpp, art2x2-table.cpp should be placed in the samplers folder of PBRT source code.
2- The following lines should be inserted in the api.cpp file:
    #include "samplers/zhash.h"
    #include "samplers/z.h"                                                     // With the samplers in the include part
    .
    .
    .
        else if (name == "z")                                                   // In function MakeSampler
            sampler = CreateZSampler(paramSet, film->GetSampleBounds());
        else if (name == "zhash")
            sampler = CreateZHashSampler(paramSet, film->GetSampleBounds());
        else if (name == "z-art")
            sampler = CreateZ_ARTSampler(paramSet, film->GetSampleBounds());
        else if (name == "morton")
            sampler = CreateMortonSampler(paramSet, film->GetSampleBounds());

3- Run cmake, followed by make, as described by PBRT.

Usage:

0- Set the sampler parameter of the PBRT file to "z", "zhash", "z-art", or "morton";
1- The "z" sampler accepts an additional integer parameter, "alphabetSize", that determines the size of the recursive table. Default is 4096.



